// priority: 100
onEvent('recipes', event => {
    const removeById = [
        "quark:building/crafting/compressed/bamboo_block",
        "quark:building/crafting/compressed/potato_crate",
        "quark:building/crafting/compressed/carrot_crate",
        "quark:building/crafting/compressed/beetroot_crate",
        "minecraft:cake",
        "additionalbars:horizontal_iron_bars"
    ]

    removeById.forEach(id => {
        event.remove({id: id})
    })
})
