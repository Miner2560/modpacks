// priority: 100

onEvent("tags.items", (event) => {
    event.add("forge:furnace", [
        "quark:deepslate_furnace",
        "quark:blackstone_furnace",
        "minecraft:furnace",
    ])
    event.remove("forge:ingots/copper", [
        "copperequipment:compressed_copper",
        "copperequipment:compressed_waxed_copper"
    ])
    event.remove("forge:ingots/waxed_copper", [
        "copperequipment:compressed_waxed_copper"
    ])
})

onEvent('recipes', event => {
    event.replaceInput('minecraft:furnace', '#forge:furnace')
    event.replaceInput('copperequipment:copper_nugget', 'create:copper_nugget')
    event.replaceOutput('copperequipment:copper_nugget', 'create:copper_nugget')
    event.replaceInput('copperequipment:compressed_copper', "minecraft:copper_ingot")
    // event.remove({input: "copperequipment:compressed_copper"})
    event.remove({input: "copperequipment:compressed_waxed_copper"})
    event.remove({id: "copperequipment:compressed_copper_a"})
    event.remove({id: "copperequipment:compressed_copper_b"})
    event.remove({id: "copperequipment:compressed_waxed_copper"})
})