// priority: 100
const gamemodeFile = JsonIO.read("gamemode.json");

onEvent("tags.items", (event) => {
    if (gamemodeFile && gamemodeFile.randomOreDrop) {
        event.add("forge:ores", [
            "ftbchocolate:ice_cream_ore",
            "ftbchocolate:deepslate_ice_cream_ore",
            "ftbchocolate:sweets_ore",
            "ftbchocolate:deepslate_sweets_ore",
            "ftbchocolate:hard_candy_ore",
        ]);
        event.add("forge:ores/sweets", ["ftbchocolate:sweets_ore", "ftbchocolate:deepslate_sweets_ore"]);
        event.add("forge:ores/ice_cream", ["ftbchocolate:ice_cream_ore", "ftbchocolate:deepslate_ice_cream_ore"]);
        event.add("forge:ores/hard_candy", ["ftbchocolate:hard_candy_ore"]);
        event.add("forge:ores_in_ground/stone", [
            "ftbchocolate:ice_cream_ore",
            "ftbchocolate:deepslate_ice_cream_ore",
            "ftbchocolate:sweets_ore",
            "ftbchocolate:deepslate_sweets_ore",
        ]);
        event.add("forge:ores_in_ground/deepslate", [
            "ftbchocolate:deepslate_ice_cream_ore",
            "ftbchocolate:deepslate_sweets_ore",
        ]);
        event.add("forge:ores_in_ground/netherrack", ["ftbchocolate:hard_candy_ore"]);

        event.add("forge:pickaxe/junk", ["minecraft:wooden_pickaxe", "minecraft:stone_pickaxe"]);
        event.add("forge:pickaxe/common", [
            "minecraft:golden_pickaxe",
            "minecraft:iron_pickaxe",
            "copperequipment:copper_pickaxe",
            "copperequipment:waxed_copper_pickaxe",
        ]);
        event.add("forge:pickaxe/rare", ["minecraft:diamond_pickaxe"]);
        event.add("forge:pickaxe/epic", ["minecraft:netherite_pickaxe"]);
        event.add("forge:pickaxe/legendary", [
            "advancednetherite:netherite_iron_pickaxe",
            "advancednetherite:netherite_gold_pickaxe",
            "advancednetherite:netherite_emerald_pickaxe",
            "advancednetherite:netherite_diamond_pickaxe",
        ]);
        event.add("forge:pickaxe", [
            "#forge:pickaxe/junk",
            "#forge:pickaxe/common",
            "#forge:pickaxe/rare",
            "#forge:pickaxe/epic",
            "#forge:pickaxe/legendary",
        ]);
    }
});

onEvent("block.loot_tables", (event) => {
    if (gamemodeFile && gamemodeFile.randomOreDrop) {
        event.addBlock("ftbchocolate:ice_cream_ore", (table) => {
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/copper_ore").weight(42);
                pool.addLootTable("minecraft:blocks/iron_ore").weight(50);
                pool.addLootTable("create:blocks/zinc_ore").weight(30);
                pool.addLootTable("minecraft:blocks/gold_ore").weight(8);
                pool.addCondition({
                    condition: "minecraft:survives_explosion",
                });
                pool.addCondition({
                    condition: "minecraft:inverted",
                    term: {
                        condition: "minecraft:match_tool",
                        predicate: {
                            tag: "forge:pickaxe",
                        },
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/copper_ore").weight(42);
                pool.addLootTable("minecraft:blocks/iron_ore").weight(50);
                pool.addLootTable("create:blocks/zinc_ore").weight(32);
                pool.addLootTable("minecraft:blocks/gold_ore").weight(8);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/junk",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/copper_ore").weight(39);
                pool.addLootTable("minecraft:blocks/iron_ore").weight(47);
                pool.addLootTable("create:blocks/zinc_ore").weight(29);
                pool.addLootTable("minecraft:blocks/gold_ore").weight(14);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/common",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/copper_ore").weight(36);
                pool.addLootTable("minecraft:blocks/iron_ore").weight(44);
                pool.addLootTable("create:blocks/zinc_ore").weight(27);
                pool.addLootTable("minecraft:blocks/gold_ore").weight(20);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/rare",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/copper_ore").weight(34);
                pool.addLootTable("minecraft:blocks/iron_ore").weight(42);
                pool.addLootTable("create:blocks/zinc_ore").weight(25);
                pool.addLootTable("minecraft:blocks/gold_ore").weight(24);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/epic",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/copper_ore").weight(25);
                pool.addLootTable("minecraft:blocks/iron_ore").weight(25);
                pool.addLootTable("create:blocks/zinc_ore").weight(25);
                pool.addLootTable("minecraft:blocks/gold_ore").weight(25);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/legendary",
                    },
                });
            });
        });

        event.addBlock("ftbchocolate:deepslate_ice_cream_ore", (table) => {
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/copper_ore").weight(42);
                pool.addLootTable("minecraft:blocks/iron_ore").weight(50);
                pool.addLootTable("create:blocks/zinc_ore").weight(30);
                pool.addLootTable("minecraft:blocks/gold_ore").weight(8);
                pool.addCondition({
                    condition: "minecraft:survives_explosion",
                });
                pool.addCondition({
                    condition: "minecraft:inverted",
                    term: {
                        condition: "minecraft:match_tool",
                        predicate: {
                            tag: "forge:pickaxe",
                        },
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/copper_ore").weight(42);
                pool.addLootTable("minecraft:blocks/iron_ore").weight(50);
                pool.addLootTable("create:blocks/zinc_ore").weight(32);
                pool.addLootTable("minecraft:blocks/gold_ore").weight(8);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/junk",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/copper_ore").weight(39);
                pool.addLootTable("minecraft:blocks/iron_ore").weight(47);
                pool.addLootTable("create:blocks/zinc_ore").weight(29);
                pool.addLootTable("minecraft:blocks/gold_ore").weight(14);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/common",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/copper_ore").weight(36);
                pool.addLootTable("minecraft:blocks/iron_ore").weight(44);
                pool.addLootTable("create:blocks/zinc_ore").weight(27);
                pool.addLootTable("minecraft:blocks/gold_ore").weight(20);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/rare",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/copper_ore").weight(34);
                pool.addLootTable("minecraft:blocks/iron_ore").weight(42);
                pool.addLootTable("create:blocks/zinc_ore").weight(25);
                pool.addLootTable("minecraft:blocks/gold_ore").weight(24);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/epic",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/copper_ore").weight(25);
                pool.addLootTable("minecraft:blocks/iron_ore").weight(25);
                pool.addLootTable("create:blocks/zinc_ore").weight(25);
                pool.addLootTable("minecraft:blocks/gold_ore").weight(25);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/legendary",
                    },
                });
            });
        });

        event.addBlock("ftbchocolate:sweets_ore", (table) => {
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/coal_ore").weight(82.2);
                pool.addLootTable("minecraft:blocks/lapis_ore").weight(9.2);
                pool.addLootTable("minecraft:blocks/redstone_ore").weight(7);
                pool.addLootTable("minecraft:blocks/emerald_ore").weight(0.6);
                pool.addLootTable("minecraft:blocks/diamond_ore").weight(1);
                pool.addCondition({
                    condition: "minecraft:survives_explosion",
                });
                pool.addCondition({
                    condition: "minecraft:inverted",
                    term: {
                        condition: "minecraft:match_tool",
                        predicate: {
                            tag: "forge:pickaxe",
                        },
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/coal_ore").weight(82.2);
                pool.addLootTable("minecraft:blocks/lapis_ore").weight(9.2);
                pool.addLootTable("minecraft:blocks/redstone_ore").weight(7);
                pool.addLootTable("minecraft:blocks/emerald_ore").weight(0.6);
                pool.addLootTable("minecraft:blocks/diamond_ore").weight(1);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/junk",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/coal_ore").weight(70.8);
                pool.addLootTable("minecraft:blocks/lapis_ore").weight(13.2);
                pool.addLootTable("minecraft:blocks/redstone_ore").weight(11);
                pool.addLootTable("minecraft:blocks/emerald_ore").weight(2);
                pool.addLootTable("minecraft:blocks/diamond_ore").weight(3);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/common",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/coal_ore").weight(64.8);
                pool.addLootTable("minecraft:blocks/lapis_ore").weight(14.2);
                pool.addLootTable("minecraft:blocks/redstone_ore").weight(12);
                pool.addLootTable("minecraft:blocks/emerald_ore").weight(4);
                pool.addLootTable("minecraft:blocks/diamond_ore").weight(5);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/rare",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/coal_ore").weight(58.8);
                pool.addLootTable("minecraft:blocks/lapis_ore").weight(16.2);
                pool.addLootTable("minecraft:blocks/redstone_ore").weight(14);
                pool.addLootTable("minecraft:blocks/emerald_ore").weight(5);
                pool.addLootTable("minecraft:blocks/diamond_ore").weight(6);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/epic",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/coal_ore").weight(50);
                pool.addLootTable("minecraft:blocks/lapis_ore").weight(18);
                pool.addLootTable("minecraft:blocks/redstone_ore").weight(17);
                pool.addLootTable("minecraft:blocks/emerald_ore").weight(7);
                pool.addLootTable("minecraft:blocks/diamond_ore").weight(8);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/legendary",
                    },
                });
            });
        });

        event.addBlock("ftbchocolate:deepslate_sweets_ore", (table) => {
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/coal_ore").weight(82.2);
                pool.addLootTable("minecraft:blocks/lapis_ore").weight(9.2);
                pool.addLootTable("minecraft:blocks/redstone_ore").weight(7);
                pool.addLootTable("minecraft:blocks/emerald_ore").weight(0.6);
                pool.addLootTable("minecraft:blocks/diamond_ore").weight(1);
                pool.addCondition({
                    condition: "minecraft:survives_explosion",
                });
                pool.addCondition({
                    condition: "minecraft:inverted",
                    term: {
                        condition: "minecraft:match_tool",
                        predicate: {
                            tag: "forge:pickaxe",
                        },
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/coal_ore").weight(82.2);
                pool.addLootTable("minecraft:blocks/lapis_ore").weight(9.2);
                pool.addLootTable("minecraft:blocks/redstone_ore").weight(7);
                pool.addLootTable("minecraft:blocks/emerald_ore").weight(0.6);
                pool.addLootTable("minecraft:blocks/diamond_ore").weight(1);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/junk",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/coal_ore").weight(70.8);
                pool.addLootTable("minecraft:blocks/lapis_ore").weight(13.2);
                pool.addLootTable("minecraft:blocks/redstone_ore").weight(11);
                pool.addLootTable("minecraft:blocks/emerald_ore").weight(2);
                pool.addLootTable("minecraft:blocks/diamond_ore").weight(3);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/common",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/coal_ore").weight(64.8);
                pool.addLootTable("minecraft:blocks/lapis_ore").weight(14.2);
                pool.addLootTable("minecraft:blocks/redstone_ore").weight(12);
                pool.addLootTable("minecraft:blocks/emerald_ore").weight(4);
                pool.addLootTable("minecraft:blocks/diamond_ore").weight(5);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/rare",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/coal_ore").weight(58.8);
                pool.addLootTable("minecraft:blocks/lapis_ore").weight(16.2);
                pool.addLootTable("minecraft:blocks/redstone_ore").weight(14);
                pool.addLootTable("minecraft:blocks/emerald_ore").weight(5);
                pool.addLootTable("minecraft:blocks/diamond_ore").weight(6);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/epic",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/coal_ore").weight(50);
                pool.addLootTable("minecraft:blocks/lapis_ore").weight(18);
                pool.addLootTable("minecraft:blocks/redstone_ore").weight(17);
                pool.addLootTable("minecraft:blocks/emerald_ore").weight(7);
                pool.addLootTable("minecraft:blocks/diamond_ore").weight(8);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/legendary",
                    },
                });
            });
        });

        event.addBlock("ftbchocolate:hard_candy_ore", (table) => {
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/nether_gold_ore").weight(71.7);
                pool.addLootTable("minecraft:blocks/nether_quartz_ore").weight(28);
                pool.addLootTable("minecraft:blocks/ancient_debris").weight(0.3);
                pool.addCondition({
                    condition: "minecraft:survives_explosion",
                });
                pool.addCondition({
                    condition: "minecraft:inverted",
                    term: {
                        condition: "minecraft:match_tool",
                        predicate: {
                            tag: "forge:pickaxe",
                        },
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/nether_gold_ore").weight(71.2);
                pool.addLootTable("minecraft:blocks/nether_quartz_ore").weight(28);
                pool.addLootTable("minecraft:blocks/ancient_debris").weight(0.8);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/junk",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/nether_gold_ore").weight(66.7);
                pool.addLootTable("minecraft:blocks/nether_quartz_ore").weight(32);
                pool.addLootTable("minecraft:blocks/ancient_debris").weight(1.3);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/common",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/nether_gold_ore").weight(52);
                pool.addLootTable("minecraft:blocks/nether_quartz_ore").weight(44);
                pool.addLootTable("minecraft:blocks/ancient_debris").weight(2);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/rare",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/nether_gold_ore").weight(49);
                pool.addLootTable("minecraft:blocks/nether_quartz_ore").weight(46);
                pool.addLootTable("minecraft:blocks/ancient_debris").weight(5);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/epic",
                    },
                });
            });
            table.addPool((pool) => {
                pool.rolls = 1;
                pool.addLootTable("minecraft:blocks/nether_gold_ore").weight(42);
                pool.addLootTable("minecraft:blocks/nether_quartz_ore").weight(50);
                pool.addLootTable("minecraft:blocks/ancient_debris").weight(8);
                pool.addCondition({
                    condition: "minecraft:match_tool",
                    predicate: {
                        tag: "forge:pickaxe/legendary",
                    },
                });
            });
        });
    }
});

onEvent("tags.blocks", (event) => {
    if (gamemodeFile && gamemodeFile.randomOreDrop) {
        event.add("minecraft:mineable/pickaxe", [
            "ftbchocolate:ice_cream_ore",
            "ftbchocolate:deepslate_ice_cream_ore",
            "ftbchocolate:sweets_ore",
            "ftbchocolate:deepslate_sweets_ore",
            "ftbchocolate:hard_candy_ore",
        ]);
    }
});
