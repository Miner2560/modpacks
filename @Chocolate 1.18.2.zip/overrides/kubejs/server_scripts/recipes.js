// priority: 99
onEvent('recipes', event => {
    const colors = [
        "white",
        "orange",
        "magenta",
        "light_blue",
        "yellow",
        "lime",
        "pink",
        "gray",
        "light_gray",
        "cyan",
        "purple",
        "blue",
        "brown",
        "green",
        "red",
        "black"
    ]

    colors.forEach(color => {
        event.remove({id: `comforts:sleeping_bag_${color}`});
        event.shaped(Item.of(`comforts:sleeping_bag_${color}`), [
            ' W ',
            ' W ',
            ' W '
        ], {
            W: `minecraft:${color}_wool`
        })
    })

    // event.remove({id: "mcwfences:acacia_horse_fence"})
    // event.remove({id: "cfm:acacia_upgraded_fence"})
    // event.shapeless("absentbydesign:fence_log_acacia", ["cfm:acacia_upgraded_fence"]);
    // event.shapeless("cfm:acacia_upgraded_fence", ["mcwfences:acacia_horse_fence"]);
    // event.shapeless("mcwfences:acacia_horse_fence", ["absentbydesign:fence_log_acacia"]);
    //
    // event.remove({id: "mcwfences:birch_horse_fence"})
    // event.remove({id: "cfm:birch_upgraded_fence"})
    // event.shapeless("absentbydesign:fence_log_birch", ["cfm:birch_upgraded_fence"]);
    // event.shapeless("cfm:birch_upgraded_fence", ["mcwfences:birch_horse_fence"]);
    // event.shapeless("mcwfences:birch_horse_fence", ["absentbydesign:fence_log_birch"]);
    //
    // event.remove({id: "mcwfences:spruce_horse_fence"})
    // event.remove({id: "cfm:spruce_upgraded_fence"})
    // event.shapeless("absentbydesign:fence_log_spruce", ["cfm:spruce_upgraded_fence"]);
    // event.shapeless("cfm:spruce_upgraded_fence", ["mcwfences:spruce_horse_fence"]);
    // event.shapeless("mcwfences:spruce_horse_fence", ["absentbydesign:fence_log_spruce"]);
    //
    // event.remove({id: "mcwfences:dark_oak_horse_fence"})
    // event.remove({id: "cfm:dark_oak_upgraded_fence"})
    // event.shapeless("absentbydesign:fence_log_darkoak", ["cfm:dark_oak_upgraded_fence"]);
    // event.shapeless("cfm:dark_oak_upgraded_fence", ["mcwfences:dark_oak_horse_fence"]);
    // event.shapeless("mcwfences:dark_oak_horse_fence", ["absentbydesign:fence_log_darkoak"]);
    //
    // event.remove({id: "mcwfences:jungle_horse_fence"})
    // event.remove({id: "cfm:jungle_upgraded_fence"})
    // event.shapeless("absentbydesign:fence_log_jungle", ["cfm:jungle_upgraded_fence"]);
    // event.shapeless("cfm:jungle_upgraded_fence", ["mcwfences:jungle_horse_fence"]);
    // event.shapeless("mcwfences:jungle_horse_fence", ["absentbydesign:fence_log_jungle"]);
    //
    // event.remove({id: "mcwfences:oak_horse_fence"})
    // event.remove({id: "cfm:oak_upgraded_fence"})
    // event.shapeless("absentbydesign:fence_log_oak", ["cfm:oak_upgraded_fence"]);
    // event.shapeless("cfm:oak_upgraded_fence", ["mcwfences:oak_horse_fence"]);
    // event.shapeless("mcwfences:oak_horse_fence", ["absentbydesign:fence_log_oak"]);
    //
    // event.remove({id: "mcwfences:crimson_horse_fence"})
    // event.remove({id: "cfm:crimson_upgraded_fence"})
    // event.shapeless("absentbydesign:fence_crimson", ["cfm:crimson_upgraded_fence"]);
    // event.shapeless("cfm:crimson_upgraded_fence", ["mcwfences:crimson_horse_fence"]);
    // event.shapeless("mcwfences:crimson_horse_fence", ["absentbydesign:fence_crimson"]);
    //
    // event.remove({id: "mcwfences:warped_horse_fence"})
    // event.remove({id: "cfm:warped_upgraded_fence"})
    // event.shapeless("absentbydesign:fence_warped", ["cfm:warped_upgraded_fence"]);
    // event.shapeless("cfm:warped_upgraded_fence", ["mcwfences:warped_horse_fence"]);
    // event.shapeless("mcwfences:warped_horse_fence", ["absentbydesign:fence_warped"]);


    const l = [
        "oak",
        "spruce",
        "birch",
        "jungle",
        "acacia",
        "dark_oak"
    ]

    const s = [
        "warped",
        "crimson"
    ]

    l.forEach(v => {
        event.remove({id: `cfm:stripped_${v}_bedside_cabinet`});
        event.shaped(Item.of(`cfm:stripped_${v}_bedside_cabinet`), [
            'WWW',
            'LSL',
            'LLL'
        ], {
            W: `minecraft:stripped_${v}_log`,
            L: `minecraft:${v}_log`,
            S: "#forge:rods/wooden"
        })


        event.remove({id: `cfm:stripped_${v}_crate`});
        event.shaped(Item.of(`cfm:stripped_${v}_crate`), [
            'WLW',
            'LSL',
            'WLW'
        ], {
            W: `minecraft:stripped_${v}_log`,
            L: `minecraft:${v}_log`,
            S: "#forge:rods/wooden"
        })

        event.remove({id: `cfm:stripped_${v}_cabinet`});
        event.shaped(Item.of(`cfm:stripped_${v}_cabinet`), [
            'WWL',
            'WSL',
            'WWL'
        ], {
            W: `minecraft:stripped_${v}_log`,
            L: `minecraft:${v}_log`,
            S: "#forge:rods/wooden"
        })
    })

    s.forEach(v => {
        event.remove({id: `cfm:stripped_${v}_bedside_cabinet`});
        event.shaped(Item.of(`cfm:stripped_${v}_bedside_cabinet`), [
            'WWW',
            'LSL',
            'LLL'
        ], {
            W: `minecraft:stripped_${v}_stem`,
            L: `minecraft:${v}_stem`,
            S: "#forge:rods/wooden"
        })


        event.remove({id: `cfm:stripped_${v}_crate`});
        event.shaped(Item.of(`cfm:stripped_${v}_crate`), [
            'WLW',
            'LSL',
            'WLW'
        ], {
            W: `minecraft:stripped_${v}_stem`,
            L: `minecraft:${v}_stem`,
            S: "#forge:rods/wooden"
        })

        event.remove({id: `cfm:stripped_${v}_cabinet`});
        event.shaped(Item.of(`cfm:stripped_${v}_cabinet`), [
            'WWL',
            'WSL',
            'WWL'
        ], {
            W: `minecraft:stripped_${v}_stem`,
            L: `minecraft:${v}_stem`,
            S: "#forge:rods/wooden"
        })
    })

    event.shapeless(Item.of('minecraft:ladder'), ['quark:spruce_ladder'])
    event.shapeless(Item.of('minecraft:ladder'), ['quark:birch_ladder'])
    event.shapeless(Item.of('minecraft:ladder'), ['quark:jungle_ladder'])
    event.shapeless(Item.of('minecraft:ladder'), ['quark:acacia_ladder'])
    event.shapeless(Item.of('minecraft:ladder'), ['quark:dark_oak_ladder'])
    event.shapeless(Item.of('minecraft:ladder'), ['quark:crimson_ladder'])
    event.shapeless(Item.of('minecraft:ladder'), ['quark:warped_ladder'])
})
