let metadataFile = JsonIO.read('config/metadata.json');

onEvent("ui.main_menu", (event) => {
    event.replace((ui) => {
        ui.shaderBackground();
        ui.widgetTexture = "ftbchocolate:textures/widgets.png";

        // If MT is loaded
        if (Platform.mods.minetogether) {
            // MineTogether friends list
            ui.button((b) => {
                b.name = "Friends list";
                b.w = 70;
                b.x = ui.w - b.w - 5;
                b.y = 5;
                b.action = "minetogether:friends_list";
                b.shadow = false;
            });

            // MineTogether chat
            ui.imageButton((b) => {
                b.w = 20;
                b.x = ui.w - b.w - 80;
                b.y = 5;
                b.action = "minetogether:chat";
                b.texture = "ftbchocolate:textures/chat.png";
            });

            // MineTogether order server
            ui.imageButton((b) => {
                b.w = 20;
                b.x = ui.w - b.w - 105;
                b.y = 5;
                b.action = "minetogether:order";
                b.texture = "ftbchocolate:textures/creeper.png";
            });
        }

        // Singleplayer
        ui.button((b) => {
            b.name = Text.translate("menu.singleplayer");
            b.w = 150;
            b.x = ui.w * 0.1;
            b.y = ui.h / 2 - 62;
            b.action = "minecraft:singleplayer";
            b.shadow = false;
        });

        // Multiplayer
        ui.button((b) => {
            b.name = Text.translate("menu.multiplayer");
            b.w = 150;
            b.x = ui.w * 0.1;
            b.y = ui.h / 2 - 36;
            b.action = "minecraft:multiplayer";
            b.shadow = false;
        });

        // Mods
        ui.button((b) => {
            b.name = Text.translate("fml.menu.mods");
            b.w = 73;
            b.x = ui.w * 0.1;
            b.y = ui.h / 2 - 10;
            b.action = "forge:mod_list";
            b.shadow = false;
        });

        // Issue tracker
        ui.button((b) => {
            b.name = Text.of("Support");
            b.w = 73;
            b.x = ui.w * 0.1 + b.w + 5;
            b.y = ui.h / 2 - 10;
            b.action = "https://www.feed-the-beast.com/support";
            b.shadow = false;
        });

        // Options
        ui.button((b) => {
            b.name = Text.translate("menu.options");
            b.w = 73;
            b.x = ui.w * 0.1;
            b.y = ui.h / 2 + 42;
            b.action = "minecraft:options";
            b.shadow = false;
        });

        // Quit
        ui.button((b) => {
            b.name = Text.of("Quit");
            b.w = 73;
            b.x = ui.w * 0.1 + b.w + 5;
            b.y = ui.h / 2 + 42;
            b.action = "minecraft:quit";
            b.shadow = false;
        });

        // Aux
        ui.imageButton((b) => {
            b.w = 20;
            b.x = 5;
            b.y = 5;
            b.action = "ftbauxilium:opt_out";
            b.texture = "ftbchocolate:textures/auxilium.png";
        });

        // Discord
        ui.imageButton((b) => {
            b.texture = "ftbchocolate:textures/discord.png"
            b.w = 20;
            b.x = 30;
            b.y = 5;
            b.action = "https://go.ftb.team/Fkgb";
        });

        // Pack logo
        ui.image((i) => {
            i.h = ui.w * 0.45;
            i.w = ui.w * 0.45;
            i.x = ui.w - i.w - (ui.w * 0.03);
            i.y = ui.h / 2 - i.h / 2;
            i.texture = "ftbchocolate:textures/logo.png";
        });

        // Forge version
        ui.label((l) => {
            l.h = 10;
            l.name = Text.of("Forge Version: " + Platform.mods.forge.version).color(0x8E4F3D);
            l.x = ui.w - l.w - 3;
            l.y = ui.h - 31;
        });

        // Mods loaded
        ui.label((l) => {
            l.h = 10;
            l.name = Text.of(Platform.mods.size() + " Mods Loaded").color(0x8E4F3D);
            l.x = ui.w - l.w - 3;
            l.y = ui.h - 21;
        });

        // Mojang
        ui.label((l) => {
            l.h = 10;
            l.name = Text.of("Copyright Mojang AB").color(0x8E4F3D);
            l.x = ui.w - l.w - 3;
            l.y = ui.h - 11;
        });

        // Pack name and version from metadata file
        if(metadataFile) {
            ui.label(l => {
                l.h = 10;
                l.name = Text.of(metadataFile.name + " v" + metadataFile.version.name).color(0x8E4F3D);
                l.x = 4;
                l.y = ui.h - 11;
            })
        }
    });
});
