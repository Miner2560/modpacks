// priority: 100

const gamemodeFile = JsonIO.read("gamemode.json");

onEvent("worldgen.remove", (event) => {
    console.log("hello im here!");
    // event.printFeatures(null, "terralith:cave/fungal_caves");
    // event.printFiltered(null, "minecraft:lush_caves");
    if (gamemodeFile && gamemodeFile.randomOreDrop) {
        event.removeOres((ores) => {
            ores.blocks = [
                "minecraft:coal_ore",
                "minecraft:deepslate_coal_ore",
                "minecraft:iron_ore",
                "minecraft:deepslate_iron_ore",
                "minecraft:copper_ore",
                "minecraft:deepslate_copper_ore",
                "minecraft:gold_ore",
                "minecraft:deepslate_gold_ore",
                "minecraft:redstone_ore",
                "minecraft:deepslate_redstone_ore",
                "minecraft:emerald_ore",
                "minecraft:deepslate_emerald_ore",
                "minecraft:lapis_ore",
                "minecraft:deepslate_lapis_ore",
                "minecraft:diamond_ore",
                "minecraft:deepslate_diamond_ore",
                "minecraft:nether_gold_ore",
                "minecraft:nether_quartz_ore",
                "minecraft:ancient_debris",
            ];
        });

        event.removeFeatureById("underground_ores", [
            "minecraft:create_striated_ores_overworld",
            "minecraft:create_zinc_ore",
        ]);

        event.removeFeatureById("underground_decoration", [
            "minecraft:ore_gold_nether",
            "minecraft:ore_quartz_nether",
            "minecraft:ore_ancient_debris_large",
            "minecraft:ore_debris_small",
            "minecraft:ore_gold_deltas",
            "minecraft:ore_quartz_deltas",
        ]);

        event.removeFeatureById("vegetal_decoration", [
            "terralith:cave/desert/noise_reducer",
            "terralith:cave/desert/noise_reducer_small",
            "terralith:cave/generic/noise_reducer",
            "terralith:cave/generic/noise_reducer_small",
            "terralith:cave/generic/ds_reducer",
            "terralith:cave/generic/ds_reducer_small",
            "terralith:cave/taiga/mega/boulders",
        ]);
    }
});

onEvent("worldgen.add", (event) => {
    if (gamemodeFile && gamemodeFile.randomOreDrop) {
        // deepslate_ore_replaceables
        event.addOre((ore) => {
            ore.id = "ftbchocolate:ice_cream_ore";
            ore.biomes = [
                {
                    not: {
                        category: "nether",
                    },
                },
            ];
            ore.addTarget("#minecraft:stone_ore_replaceables", "ftbchocolate:ice_cream_ore");

            ore.count([5, 14]).size(20).squared().triangleHeight(-64, 210);
        });

        event.addOre((ore) => {
            ore.id = "ftbchocolate:deepslate_ice_cream_ore";
            ore.biomes = [
                {
                    not: {
                        category: "nether",
                    },
                },
            ];
            ore.addTarget("#minecraft:deepslate_ore_replaceables", "ftbchocolate:deepslate_ice_cream_ore");

            ore.count([5, 14]).size(20).squared().triangleHeight(-64, 210);
        });

        event.addOre((ore) => {
            ore.id = "ftbchocolate:sweets_ore";
            ore.biomes = [
                {
                    not: {
                        category: "nether",
                    },
                },
            ];
            ore.addTarget("#minecraft:stone_ore_replaceables", "ftbchocolate:sweets_ore");

            ore.count([5, 11]).size(20).squared().triangleHeight(-64, 210);
        });

        event.addOre((ore) => {
            ore.id = "ftbchocolate:deepslate_sweets_ore";
            ore.biomes = [
                {
                    not: {
                        category: "nether",
                    },
                },
            ];
            ore.addTarget("#minecraft:deepslate_ore_replaceables", "ftbchocolate:deepslate_sweets_ore");

            ore.count([5, 11]).size(20).squared().triangleHeight(-64, 210);
        });

        event.addOre((ore) => {
            ore.id = "ftbchocolate:hard_candy_ore";
            ore.biomes = [
                {
                    category: "nether",
                },
            ];
            ore.addTarget("minecraft:netherrack", "ftbchocolate:hard_candy_ore");

            ore.count([5, 14]).size(20).squared().triangleHeight(0, 192);
        });
    }
});

onEvent("block.registry", (event) => {
    if (gamemodeFile && gamemodeFile.randomOreDrop) {
        event.create("ftbchocolate:ice_cream_ore").material("stone").hardness(3).resistance(3);
        event.create("ftbchocolate:deepslate_ice_cream_ore").material("stone").hardness(3).resistance(3);
        event.create("ftbchocolate:sweets_ore").material("stone").hardness(3).resistance(3);
        event.create("ftbchocolate:deepslate_sweets_ore").material("stone").hardness(3).resistance(3);
        event.create("ftbchocolate:hard_candy_ore").material("stone").hardness(3).resistance(3);
    }
});
